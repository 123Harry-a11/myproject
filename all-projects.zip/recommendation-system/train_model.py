import pandas as pd
import numpy as np
import pickle
from sklearn.metrics.pairwise import cosine_similarity

# ── 1. Load / Generate Data ───────────────────────────────────────────────────
# Using MovieLens 100K dataset
# Download from: https://grouplens.org/datasets/movielens/100k/
# Place u.data and u.item in this directory

try:
    # Ratings
    ratings = pd.read_csv('u.data', sep='\t', header=None,
                          names=['user_id', 'item_id', 'rating', 'timestamp'])
    # Movies
    movies = pd.read_csv('u.item', sep='|', encoding='latin-1', header=None,
                         usecols=[0, 1], names=['item_id', 'title'])
except FileNotFoundError:
    print("[INFO] MovieLens files not found – generating synthetic data.")
    np.random.seed(42)
    n_users, n_items = 50, 30
    users   = np.random.randint(1, n_users + 1, 400)
    items   = np.random.randint(1, n_items + 1, 400)
    ratings_val = np.random.randint(1, 6, 400)
    ratings = pd.DataFrame({'user_id': users, 'item_id': items,
                            'rating': ratings_val, 'timestamp': 0})
    ratings.drop_duplicates(['user_id', 'item_id'], inplace=True)
    movies  = pd.DataFrame({'item_id': range(1, n_items + 1),
                            'title': [f'Movie {i}' for i in range(1, n_items + 1)]})

print(f"Ratings : {ratings.shape}")
print(f"Movies  : {movies.shape}")

# ── 2. Build User-Item Matrix ─────────────────────────────────────────────────
matrix = ratings.pivot_table(index='user_id', columns='item_id',
                              values='rating').fillna(0)
print(f"User-Item matrix: {matrix.shape}")

# ── 3. Collaborative Filtering (User-Based) ───────────────────────────────────
user_similarity = cosine_similarity(matrix)
user_sim_df = pd.DataFrame(user_similarity,
                           index=matrix.index, columns=matrix.index)

# ── 4. Recommendation Function ────────────────────────────────────────────────
def recommend(user_id, n=5):
    if user_id not in matrix.index:
        return []

    sim_scores  = user_sim_df[user_id].drop(user_id).sort_values(ascending=False)
    top_users   = sim_scores.head(10).index
    top_ratings = matrix.loc[top_users]

    already_rated = matrix.loc[user_id][matrix.loc[user_id] > 0].index
    mean_scores   = top_ratings.mean(axis=0)
    mean_scores   = mean_scores.drop(already_rated, errors='ignore')
    top_items     = mean_scores.nlargest(n).index

    recs = movies[movies['item_id'].isin(top_items)][['item_id', 'title']].copy()
    recs['score'] = recs['item_id'].map(mean_scores)
    return recs.sort_values('score', ascending=False).to_dict('records')

# ── 5. Test ───────────────────────────────────────────────────────────────────
sample_user = matrix.index[0]
print(f"\nTop 5 recommendations for user {sample_user}:")
for r in recommend(sample_user):
    print(f"  {r['title']}  (score={r['score']:.2f})")

# ── 6. Save Artefacts ─────────────────────────────────────────────────────────
with open('matrix.pkl',     'wb') as f: pickle.dump(matrix, f)
with open('user_sim.pkl',   'wb') as f: pickle.dump(user_sim_df, f)
with open('movies.pkl',     'wb') as f: pickle.dump(movies, f)
print("\nArtefacts saved.")
