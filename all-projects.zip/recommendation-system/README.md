# 🎬 Smart Recommendation System

End-to-end collaborative filtering recommendation engine using user behavior analysis.

## 🔧 Tech Stack
- Python, Pandas, Numpy, Scikit-learn
- Collaborative Filtering (User-Based cosine similarity)
- Flask (backend API)
- HTML/CSS/JavaScript (frontend)

## 📁 Project Structure
```
recommendation-system/
├── train_model.py      # Training script
├── app.py              # Flask API
├── templates/
│   └── index.html      # Web interface
├── requirements.txt
└── README.md
```

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Download Dataset (Optional)
Download [MovieLens 100K](https://grouplens.org/datasets/movielens/100k/) and place `u.data` and `u.item` in the root. Without it, a synthetic dataset is auto-generated.

### 3. Train the model
```bash
python train_model.py
```

### 4. Run Flask app
```bash
python app.py
```
Visit `http://localhost:5000`

## 🧠 Techniques Used
- User-Item matrix construction
- Cosine similarity for user comparison
- Top-N collaborative filtering
- Already-rated item exclusion
