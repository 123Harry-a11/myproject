from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd

app = Flask(__name__)

with open('matrix.pkl',   'rb') as f: matrix    = pickle.load(f)
with open('user_sim.pkl', 'rb') as f: user_sim  = pickle.load(f)
with open('movies.pkl',   'rb') as f: movies    = pickle.load(f)

def recommend(user_id, n=5):
    user_id = int(user_id)
    if user_id not in matrix.index:
        return []
    sim_scores    = user_sim[user_id].drop(user_id).sort_values(ascending=False)
    top_users     = sim_scores.head(10).index
    top_ratings   = matrix.loc[top_users]
    already_rated = matrix.loc[user_id][matrix.loc[user_id] > 0].index
    mean_scores   = top_ratings.mean(axis=0).drop(already_rated, errors='ignore')
    top_items     = mean_scores.nlargest(n).index
    recs = movies[movies['item_id'].isin(top_items)][['item_id', 'title']].copy()
    recs['score'] = recs['item_id'].map(mean_scores).round(2)
    return recs.sort_values('score', ascending=False).to_dict('records')

@app.route('/')
def home():
    users = matrix.index.tolist()
    return render_template('index.html', users=users)

@app.route('/recommend', methods=['POST'])
def get_recommendations():
    data    = request.get_json()
    user_id = data.get('user_id')
    n       = int(data.get('n', 5))
    recs    = recommend(user_id, n)
    return jsonify({'recommendations': recs})

if __name__ == '__main__':
    app.run(debug=True)
